
import { GoogleGenAI } from "@google/genai";

if (!process.env.API_KEY) {
    console.warn("API_KEY environment variable not set. Gemini features will be disabled.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

export const generateStudyAid = async (prompt: string, content: string): Promise<string> => {
    if (!process.env.API_KEY) {
        return "A funcionalidade do Gemini está desativada. Por favor, configure a variável de ambiente API_KEY.";
    }
    
    try {
        const fullPrompt = `${prompt}\n\nConteúdo para analisar: "${content}"`;
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: fullPrompt,
            config: {
                temperature: 0.7,
            }
        });
        return response.text;
    } catch (error) {
        console.error("Error generating content with Gemini:", error);
        return "Ocorreu um erro ao gerar o conteúdo. Por favor, tente novamente.";
    }
};
